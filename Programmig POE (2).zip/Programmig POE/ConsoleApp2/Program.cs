﻿using CyberSecurityChatBot;
using System;

namespace CyberSecurityChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Bot";

            // Display ASCII art logo
            UIHelper.DisplayHeader();

            AsciiArt.Display();

            // Play voice greeting
            AudioPlayer.PlayGreeting();

            // Ask for user name
            Console.Write("\nEnter your name: ");
            string name = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(name))
            {
                Console.Write("⚠️ Name cannot be empty. Enter your name: ");
                name = Console.ReadLine();
            }

            // Start chatbot
            Chatbot bot = new Chatbot(name);
            bot.StartChat();
        }
    }
}