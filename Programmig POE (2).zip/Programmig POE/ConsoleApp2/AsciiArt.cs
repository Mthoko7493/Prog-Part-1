﻿using System;
using System.Drawing;
using System.IO;
using System.Security.Policy;
using System.Text;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Converts an image file into ASCII characters and prints it to the console.
    /// </summary>
    static class AsciiArt
    {
        // Characters ordered from darkest to lightest for ASCII mapping
        private static readonly char[] asciiChars =
        { '@', '#', 'S', '%', '?', '*', '+', ';', ':', ',', '.' };

        public static void Display()
        {
            Console.Clear();

            // Path to the image file (must exist in project/output folder)
            string imagePath = "logo.png";

            // Check if the image exists before processing
            if (!File.Exists(imagePath))
            {
                Console.WriteLine("Image not found. Please add 'logo.png' to the project folder.");
                return;
            }

            Bitmap image = new Bitmap(imagePath);

            // Resize image to fit console width while maintaining aspect ratio
            int width = 100;
            int height = (int)(image.Height * width / (double)image.Width);

            Bitmap resized = new Bitmap(image, new Size(width, height));

            StringBuilder asciiImage = new StringBuilder();

            // Convert each pixel into an ASCII character
            for (int y = 0; y < resized.Height; y++)
            {
                for (int x = 0; x < resized.Width; x++)
                {
                    Color pixel = resized.GetPixel(x, y);

                    // Convert RGB pixel to grayscale intensity
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;

                    // Map grayscale value to corresponding ASCII character
                    int index = gray * (asciiChars.Length - 1) / 255;
                    asciiImage.Append(asciiChars[index]);
                }

                // Move to next line after finishing each row
                asciiImage.AppendLine();
            }

            // Display ASCII art in cyan color for better visibility
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(asciiImage.ToString());
            Console.ResetColor();
        }
    }
}