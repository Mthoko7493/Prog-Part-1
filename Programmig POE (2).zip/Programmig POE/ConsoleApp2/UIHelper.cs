﻿using System;
using System.Threading;




namespace CyberSecurityChatbot
{
    public static class UIHelper
    {
        public static void DisplayHeader()
        {
            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine("╔══════════════════════════════════════╗");
            Console.WriteLine("║   🔐 CYBERSECURITY AWARENESS BOT 🔐  ║");
            Console.WriteLine("╚══════════════════════════════════════╝");

            Console.WriteLine(@"
        [ Protect • Detect • Respond ]
");

            Console.ResetColor();
        }

        public static void Section(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n=== {title} ===");
            Console.ResetColor();
        }

        public static void TypeText(string text)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(15);
            }
            Console.WriteLine();
        }
    }
}