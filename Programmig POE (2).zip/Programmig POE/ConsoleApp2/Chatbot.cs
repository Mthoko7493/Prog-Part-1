﻿using System;

namespace CyberSecurityChatbot
{
    public class Chatbot
    {
        public string UserName { get; set; }

        public Chatbot(string name)
        {
            UserName = name;
        }

        public void StartChat()
        {
            UIHelper.TypeText($"\nWelcome {UserName}! 👋");
            UIHelper.TypeText("I'm your Cybersecurity Assistant. Let's keep you safe online 🔐\n");

            while (true)
            {
                ShowMainMenu();

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("\nSelect an option (1–7) or type a question ➤ ");
                Console.ResetColor();

                string input = Console.ReadLine()?.ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    UIHelper.TypeText("⚠️ Please enter a valid option.");
                    continue;
                }

                if (input == "7" || input.Contains("exit") || input.Contains("bye"))
                {
                    UIHelper.TypeText($"Goodbye {UserName}! Stay safe online 🔐");
                    break;
                }

                HandleInput(input);
            }
        }

        private void ShowMainMenu()
        {
            UIHelper.TypeText("\n📋 MAIN MENU:");
            Console.WriteLine("1. Password Safety");
            Console.WriteLine("2. Phishing Scams");
            Console.WriteLine("3. Safe Browsing");
            Console.WriteLine("4. Malware & Viruses");
            Console.WriteLine("5. Social Engineering");
            Console.WriteLine("6. General Cybersecurity Tips");
            Console.WriteLine("7. Exit");
        }

        private void HandleInput(string input)
        {
            switch (input)
            {
                case "1":
                    ShowPasswordTips();
                    break;
                case "2":
                    ShowPhishingTips();
                    break;
                case "3":
                    ShowBrowsingTips();
                    break;
                case "4":
                    ShowMalwareTips();
                    break;
                case "5":
                    ShowSocialEngineeringTips();
                    break;
                case "6":
                    ShowGeneralTips();
                    break;
                default:
                    RespondToText(input);
                    break;
            }
        }

        // 🔐 PASSWORDS
        private void ShowPasswordTips()
        {
            UIHelper.TypeText("\n🔐 PASSWORD SAFETY:");

            Console.WriteLine("1. Use at least 12 characters.");
            Console.WriteLine("2. Include uppercase, lowercase, numbers, and symbols.");
            Console.WriteLine("3. Avoid personal information.");
            Console.WriteLine("4. Never reuse passwords.");
            Console.WriteLine("5. Use a password manager.");
        }

        // 🎣 PHISHING
        private void ShowPhishingTips()
        {
            UIHelper.TypeText("\n🎣 PHISHING SCAMS:");

            Console.WriteLine("1. Check the sender’s email carefully.");
            Console.WriteLine("2. Do not click suspicious links.");
            Console.WriteLine("3. Watch for urgency or threats.");
            Console.WriteLine("4. Never share sensitive information.");
            Console.WriteLine("5. Report phishing attempts.");
        }

        // 🌐 BROWSING
        private void ShowBrowsingTips()
        {
            UIHelper.TypeText("\n🌐 SAFE BROWSING:");

            Console.WriteLine("1. Only use secure websites (https://).");
            Console.WriteLine("2. Avoid unknown downloads.");
            Console.WriteLine("3. Keep your browser updated.");
            Console.WriteLine("4. Use antivirus protection.");
            Console.WriteLine("5. Avoid suspicious pop-ups.");
        }

        // 🦠 MALWARE
        private void ShowMalwareTips()
        {
            UIHelper.TypeText("\n🦠 MALWARE & VIRUSES:");

            Console.WriteLine("1. Install antivirus software.");
            Console.WriteLine("2. Avoid pirated software.");
            Console.WriteLine("3. Keep your system updated.");
            Console.WriteLine("4. Scan files before opening.");
            Console.WriteLine("5. Be cautious with email attachments.");
        }

        // 🧠 SOCIAL ENGINEERING
        private void ShowSocialEngineeringTips()
        {
            UIHelper.TypeText("\n🧠 SOCIAL ENGINEERING:");

            Console.WriteLine("1. Attackers manipulate people.");
            Console.WriteLine("2. Do not trust unexpected requests.");
            Console.WriteLine("3. Verify identities.");
            Console.WriteLine("4. Avoid pressure tactics.");
            Console.WriteLine("5. Think before acting.");
        }

        // 🛡️ GENERAL
        private void ShowGeneralTips()
        {
            UIHelper.TypeText("\n🛡️ GENERAL CYBERSECURITY:");

            Console.WriteLine("1. Enable two-factor authentication (2FA).");
            Console.WriteLine("2. Backup important data.");
            Console.WriteLine("3. Avoid public Wi-Fi for banking.");
            Console.WriteLine("4. Keep software updated.");
            Console.WriteLine("5. Stay informed about threats.");
        }

        // 💬 FREE TEXT RESPONSE
        private void RespondToText(string input)
        {
            if (input.Contains("password"))
            {
                ShowPasswordTips();
            }
            else if (input.Contains("phishing") || input.Contains("scam"))
            {
                ShowPhishingTips();
            }
            else if (input.Contains("browsing") || input.Contains("website"))
            {
                ShowBrowsingTips();
            }
            else if (input.Contains("malware") || input.Contains("virus"))
            {
                ShowMalwareTips();
            }
            else if (input.Contains("social"))
            {
                ShowSocialEngineeringTips();
            }
            else if (input.Contains("help"))
            {
                ShowMainMenu();
            }
            else
            {
                UIHelper.TypeText("❓ I’m not sure I understand.");
                UIHelper.TypeText("Please choose an option from the menu or ask a cybersecurity question.");
            }
        }
    }
}