﻿using System;
using System.Speech.Synthesis;

namespace CyberSecurityChatbot
{
    public static class AudioPlayer
    {
        public static void PlayGreeting()
        {
            try
            {
                using (SpeechSynthesizer synth = new SpeechSynthesizer())
                {
                    synth.Volume = 100;   // 0 - 100
                    synth.Rate = 0;       // -10 to 10

                    synth.Speak("Hello! Welcome to the Cybersecurity Awareness Bot.I’m here to help you stay safe online.Ask me anything about passwords, phishing, or safe browsing.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("⚠️ Speech error: " + ex.Message);
            }
        }
    }
}